(function($) {
	$(window).load(function() {
		$('.project.portfolio-hover-style-1 .entry-thumb').each( function() { $(this).hoverdir({
			
				
			//hoverDelay : 75
			
			//hoverDelay : 50,
			//inverse : true
			
			
		}); } );
	});
})(jQuery);