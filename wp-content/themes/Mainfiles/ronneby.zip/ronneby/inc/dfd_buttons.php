<a class="dfd-fixed-button dfd-buy dfd-tablet-hide" href="http://themeforest.net/item/ronneby-highperformance-wordpress-theme/11776839" title="purchase theme" target="_blank"><i class="dfd-icon-trolley_add"></i><?php _e('Purchase theme', 'dfd') ?></a>
<a class="dfd-fixed-button dfd-mail dfd-tablet-hide" href="http://themeforest.net/user/DFDevelopment#contact" title="send us a message" target="_blank"><i class="dfd-icon-send_mail"></i><?php _e('Send us a message', 'dfd') ?></a>
<?php
/*
<a class="dfd-fixed-button dfd-buy dfd-tablet-hide" href="http://themeforest.net/item/ronneby-highperformance-wordpress-theme/11776839?ref=dfdevelopment&license=regular&open_purchase_for_item_id=9713415&purchasable=source" title="purchase theme" target="_blank"><i class="dfd-icon-trolley_add"></i><?php _e('Purchase theme', 'dfd') ?></a>
*/
?>